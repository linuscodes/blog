+++
title = "My awesome project"
description = "Description of my awesome project."
date = 2014-11-18T02:13:50Z
author = "My name"
+++

## About project

Aenean ipsum justo, semper eu nisl ut, pretium tincidunt sem. Praesent et diam sit amet lacus lobortis dictum a id lacus. Quisque hendrerit sit amet turpis eu varius. Ut id lorem ac felis ultrices tincidunt. Pellentesque consequat arcu ac fringilla imperdiet. Phasellus pellentesque, sapien non pulvinar blandit, sapien ante aliquet felis, vel porttitor sapien ante in lacus. Fusce non urna aliquet, malesuada nibh vel, luctus urna. Phasellus ut lacus molestie, varius purus quis, malesuada lorem.

## Install

```bash
go get -u -v github.com/spf13/hugo
```

## Docs

https://godoc.org/github.com/spf13/hugo